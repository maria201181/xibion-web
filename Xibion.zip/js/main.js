$(document).ready(function(){
  $('.mainSlider').slick({
    autoplay: false
  });
});
	