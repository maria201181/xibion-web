$(document).ready(function(){
  $('.mainSlider').slick({
  	  autoplay:true,	
	  infinite: true,
	  autoplaySpeed:2000	  
  	})
});
	